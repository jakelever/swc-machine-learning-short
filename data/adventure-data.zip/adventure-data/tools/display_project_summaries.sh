# Displays the summary of various projects
cat research_files/project_gibson/summary.txt
cat research_files/project_arcturus/summary.txt
cat research_files/project_columbia/summary.txt
cat research_files/project_asimov/summary.txt
cat research_files/project_titan/summary.txt
cat research_files/project_smith/summary.txt
